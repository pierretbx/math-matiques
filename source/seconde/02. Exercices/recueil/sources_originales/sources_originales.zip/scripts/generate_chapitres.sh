#!/bin/sh
set -eu

ROOT=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
cd "$ROOT"

mkdir -p build

extract_body() {
  input=$1
  output=$2
  awk '
    /\\begin\{document\}/ {in_doc=1; next}
    /\\end\{document\}/ {in_doc=0}
    in_doc {print}
  ' "$input" > "$output"
}

extract_body "Manu/Recueil_exercices_Seconde.tex" "build/manu_body.tex"

awk '
  /\\begin\{document\}/ {in_doc=1; next}
  /\\end\{document\}/ {in_doc=0}
  in_doc && /\\section\{/ {seen_section=1}
  in_doc && seen_section {print}
' "exos_seconde_Thierry.tex" > "build/thierry_body.tex"

for file in "Exo virginie"/*.tex; do
  base=$(basename "$file" .tex)
  extract_body "$file" "build/virginie_${base}_body.tex"
done

extract_body "Pierre/Arithmétique/Exercice.tex" "build/pierre_arithmetique_body.tex"
extract_body "Pierre/Vecteur/Exercice .tex" "build/pierre_vecteur_body.tex"
extract_body "Pierre/Représentaiton de fonction /Exercices.tex" "build/pierre_fonctions_body.tex"
extract_body "Pierre/Equation de droite et système /Exercice.tex" "build/pierre_droites_body.tex"
extract_body "Pierre/Statistiques/Exercice.tex" "build/pierre_statistiques_body.tex"
extract_body "Pierre/Information chiffrée/Exercice.tex" "build/pierre_information_chiffree_body.tex"
extract_body "Pierre/Fonction de référence/Exercice.tex" "build/pierre_fonctions_reference_body.tex"

clean_virginie() {
  input=$1
  output=$2
  awk '
    /^\\lhead\{/ {next}
    /^\\chead\{/ {next}
    /^\\rhead\{/ {next}
    /^\\cfoot\{/ {next}
    /^\\renewcommand\{\\headrulewidth\}/ {next}
    !seen_exo && /^\\begin\{minipage\}/ {skip_minipage=1; next}
    skip_minipage && /^\\end\{minipage\}/ {skip_minipage=0; next}
    skip_minipage {next}
    /chateau\.eps/ {next}
    /Fiche d/ {next}
    /^\\medskip$/ && !seen_exo {next}
    /^~~$/ {next}
    /\\exo/ {seen_exo=1}
    seen_exo {print}
  ' "$input" > "$output"
}

clean_pierre() {
  input=$1
  output=$2
  awk '
    /^[[:space:]]*\\twocolumn/ {next}
    /^[[:space:]]*\\onecolumn/ {next}
    /^[[:space:]]*\\begin\{center\}/ {skip_center=1; next}
    skip_center && /^[[:space:]]*\\end\{center\}/ {skip_center=0; next}
    skip_center {next}
    /^[[:space:]]*\\section\*\{Exercice/ {print "\\exo"; next}
    /^[[:space:]]*\\section\{/ {
      sub(/^[[:space:]]*/, "")
      sub(/^\\section\{/, "\\subsection*{")
      print
      next
    }
    {print}
  ' "$input" > "$output"
}

pierre_section_to_file() {
  input=$1
  section=$2
  output=$3
  awk -v section="$section" '
    $0 == "\\section{" section "}" {capture=1; next}
    capture && /^\\section\{/ {capture=0}
    capture {print}
  ' "$input" > "$output"
}

replace_line_with_file() {
  pattern=$1
  insert=$2
  file=$3
  tmp="${file}.tmp"
  awk -v pattern="$pattern" -v insert="$insert" '
    index($0, pattern) {
      while ((getline line < insert) > 0) print line
      close(insert)
      next
    }
    {print}
  ' "$file" > "$tmp"
  mv "$tmp" "$file"
}

section_to_file() {
  section=$1
  output=$2
  awk -v section="$section" '
    $0 == "\\section{" section "}" {capture=1; next}
    capture && /^\\section\{/ {capture=0}
    capture {print}
  ' build/thierry_body.tex > "$output"
}

make_chapter() {
  dir=$1
  title=$2
  subtitle=${3:-}
  mkdir -p "chapitres/$dir"
  printf '\\chapitreRecueil{%s}{%s}{%s}\n' "$dir" "$title" "$subtitle" > "chapitres/$dir/chapitre.tex"
}

copy_if_exists() {
  src=$1
  dest=$2
  if [ -f "$src" ]; then
    cp "$src" "$dest"
  fi
}

make_chapter "01_arithmetique" "Arithmétique"
make_chapter "02_vecteurs_1" "Vecteurs et déplacements du plan" "construction, somme, relation de Chasles, translation\ldots{} sans repère"
make_chapter "03_nombres_reels" "Nombres réels"
make_chapter "04_generalites_fonctions" "Généralités sur les fonctions"
make_chapter "05_proportions_evolutions" "Proportions et taux d'évolution"
make_chapter "06_calcul_litteral" "Calcul littéral"
make_chapter "07_vecteurs_2" "Vecteurs et coordonnées" "repère, coordonnées, calculs, milieu\ldots"
make_chapter "08_variations_fonctions" "Variations de fonctions"
make_chapter "09_fonctions_affines" "Fonctions affines"
make_chapter "10_statistiques" "Statistiques"
make_chapter "11_fonction_carree" "Fonction carré"
make_chapter "12_probabilites" "Probabilités"
make_chapter "13_fonction_racine_carree" "Fonction racine carrée"
make_chapter "14_vecteurs_3" "Vecteurs et parallélismes"
make_chapter "15_fonction_cube" "Fonction cube"
make_chapter "16_equations_droites" "Équations de droites"
make_chapter "17_fonction_inverse" "Fonction inverse"
make_chapter "18_systemes_lineaires" "Systèmes linéaires"

awk '
  BEGIN {
    dirs[1]="01_arithmetique"
    dirs[2]="02_vecteurs_1"
    dirs[3]="03_nombres_reels"
    dirs[4]="04_generalites_fonctions"
    dirs[5]="05_proportions_evolutions"
    dirs[6]="06_calcul_litteral"
    dirs[7]="07_vecteurs_2"
    dirs[8]="08_variations_fonctions"
    dirs[9]="09_fonctions_affines"
    dirs[10]="10_statistiques"
    dirs[11]="11_fonction_carree"
    dirs[12]="12_probabilites"
    dirs[13]="13_fonction_racine_carree"
    dirs[14]="14_vecteurs_3"
    dirs[15]="15_fonction_cube"
    dirs[16]="16_equations_droites"
    dirs[17]="17_fonction_inverse"
    dirs[18]="18_systemes_lineaires"
    for (i=1; i<=18; i++) {
      files[i]="chapitres/" dirs[i] "/manu.tex"
      print "" > files[i]
      close(files[i])
    }
  }
  /^%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%/ {
    skip_header=1
    next
  }
  /Chapitre [0-9]+ --/ {
    current=$0
    sub(/^.*Chapitre /, "", current)
    sub(/ --.*$/, "", current)
    file=files[current]
    skip_header=1
    next
  }
  current && skip_header && /^\\exo/ {
    skip_header=0
    print $0 >> file
    next
  }
  current && !skip_header {
    print $0 >> file
  }
' build/manu_body.tex

section_to_file "vecteurs " "chapitres/02_vecteurs_1/thierry.tex"
section_to_file "Ensembles de nombres - valeurs absolues" "chapitres/03_nombres_reels/thierry.tex"
section_to_file "lectures graphiques" "chapitres/04_generalites_fonctions/thierry.tex"
section_to_file "pourcentages" "chapitres/05_proportions_evolutions/thierry.tex"
section_to_file "variation d'une fonction et fonctions affines" "chapitres/08_variations_fonctions/thierry.tex"
section_to_file "statistiques" "chapitres/10_statistiques/thierry.tex"
section_to_file "probabilités" "chapitres/12_probabilites/thierry.tex"
section_to_file "racines carrées" "chapitres/13_fonction_racine_carree/thierry.tex"
section_to_file "vecteurs et coordonnées" "chapitres/14_vecteurs_3/thierry.tex"
section_to_file "droites et systemes" "chapitres/18_systemes_lineaires/thierry.tex"

clean_virginie "build/virginie_exo4_lect_graph_body.tex" "chapitres/04_generalites_fonctions/virginie.tex"
clean_virginie "build/virginie_exo5_evolutions_body.tex" "chapitres/05_proportions_evolutions/virginie.tex"
clean_virginie "build/virginie_exo8_var_aff_body.tex" "chapitres/08_variations_fonctions/virginie.tex"
clean_virginie "build/virginie_exo9_stat_body.tex" "chapitres/10_statistiques/virginie.tex"
clean_virginie "build/virginie_exo10_fonction_ref_body.tex" "chapitres/11_fonction_carree/virginie.tex"
clean_virginie "build/virginie_exo13_proba_body.tex" "chapitres/12_probabilites/virginie.tex"
clean_virginie "build/virginie_exo6_racine_carree_body.tex" "chapitres/13_fonction_racine_carree/virginie.tex"
clean_virginie "build/virginie_exo7_geometrie_repere_body.tex" "chapitres/14_vecteurs_3/virginie_geometrie_repere.tex"
clean_virginie "build/virginie_exo11_colinearite_body.tex" "chapitres/14_vecteurs_3/virginie_colinearite.tex"
clean_virginie "build/virginie_exo15_equa_cartesienne_body.tex" "chapitres/16_equations_droites/virginie.tex"
clean_virginie "build/virginie_exo12_signe_body.tex" "chapitres/17_fonction_inverse/virginie_signe.tex"
clean_virginie "build/virginie_exo17_quotients_body.tex" "chapitres/17_fonction_inverse/virginie_quotients.tex"

clean_pierre "build/pierre_arithmetique_body.tex" "chapitres/01_arithmetique/pierre.tex"
clean_pierre "build/pierre_fonctions_body.tex" "chapitres/04_generalites_fonctions/pierre.tex"
clean_pierre "build/pierre_information_chiffree_body.tex" "chapitres/05_proportions_evolutions/pierre.tex"
clean_pierre "build/pierre_vecteur_body.tex" "chapitres/07_vecteurs_2/pierre.tex"
clean_pierre "build/pierre_statistiques_body.tex" "chapitres/10_statistiques/pierre.tex"
clean_pierre "build/pierre_droites_body.tex" "chapitres/16_equations_droites/pierre.tex"

pierre_section_to_file "build/pierre_fonctions_reference_body.tex" "La fonction carré" "build/pierre_fonction_carree_section.tex"
pierre_section_to_file "build/pierre_fonctions_reference_body.tex" "La fonction inverse" "build/pierre_fonction_inverse_section.tex"
pierre_section_to_file "build/pierre_fonctions_reference_body.tex" "Les fonctions cube et racine carrée" "build/pierre_fonction_cube_racine_section.tex"
awk '
  /^\\section\*\{Exercice 8\}/ {capture=1}
  capture && /^\\section\*\{Exercice 9\}/ {capture=0}
  capture {print}
' "build/pierre_fonction_cube_racine_section.tex" > "build/pierre_fonction_cube_section.tex"
awk '
  /^\\section\*\{Exercice 9\}/ {capture=1}
  capture {print}
' "build/pierre_fonction_cube_racine_section.tex" > "build/pierre_fonction_racine_section.tex"
clean_pierre "build/pierre_fonction_carree_section.tex" "chapitres/11_fonction_carree/pierre.tex"
clean_pierre "build/pierre_fonction_racine_section.tex" "chapitres/13_fonction_racine_carree/pierre.tex"
clean_pierre "build/pierre_fonction_inverse_section.tex" "chapitres/17_fonction_inverse/pierre.tex"
clean_pierre "build/pierre_fonction_cube_section.tex" "chapitres/15_fonction_cube/pierre.tex"

replace_line_with_file "19202NDex8f6.eps" "snippets/virginie_code_evolutions.tex" "chapitres/05_proportions_evolutions/virginie.tex"
replace_line_with_file "courbe.eps" "snippets/virginie_courbe_lecture.tex" "chapitres/04_generalites_fonctions/virginie.tex"
replace_line_with_file "racine.eps" "snippets/virginie_graphe_racine.tex" "chapitres/11_fonction_carree/virginie.tex"
replace_line_with_file "carre.eps" "snippets/virginie_graphe_carre.tex" "chapitres/11_fonction_carree/virginie.tex"
replace_line_with_file "cube.eps" "snippets/virginie_graphe_cube.tex" "chapitres/11_fonction_carree/virginie.tex"
replace_line_with_file "roue.eps" "snippets/virginie_roue.tex" "chapitres/12_probabilites/virginie.tex"
replace_line_with_file "stat-nuage.eps" "snippets/virginie_stat_nuage.tex" "chapitres/10_statistiques/virginie.tex"
replace_line_with_file "nuagetps.eps" "snippets/virginie_nuage_temps.tex" "chapitres/10_statistiques/virginie.tex"
replace_line_with_file "fonction_ecartype.eps" "snippets/virginie_code_ecart_type.tex" "chapitres/10_statistiques/virginie.tex"
replace_line_with_file "Vect.eps" "snippets/virginie_code_vecteurs.tex" "chapitres/14_vecteurs_3/virginie_colinearite.tex"

for dir in chapitres/*; do
  if [ -f "$dir/virginie_geometrie_repere.tex" ] || [ -f "$dir/virginie_colinearite.tex" ] || [ -f "$dir/virginie_signe.tex" ] || [ -f "$dir/virginie_quotients.tex" ]; then
    {
      [ -f "$dir/virginie_geometrie_repere.tex" ] && printf '\\input{%s/virginie_geometrie_repere.tex}\n' "$dir"
      [ -f "$dir/virginie_colinearite.tex" ] && printf '\\input{%s/virginie_colinearite.tex}\n' "$dir"
      [ -f "$dir/virginie_signe.tex" ] && printf '\\input{%s/virginie_signe.tex}\n' "$dir"
      [ -f "$dir/virginie_quotients.tex" ] && printf '\\input{%s/virginie_quotients.tex}\n' "$dir"
    } > "$dir/virginie_combined.tex"
    mv "$dir/virginie_combined.tex" "$dir/virginie.tex"
  fi
done

for file in chapitres/*/*.tex; do
  tmp="${file}.tmp"
  awk '
    /^[[:space:]]*\\(newpage|pagebreak|clearpage)[[:space:]]*$/ {next}
    {print}
  ' "$file" > "$tmp"
  mv "$tmp" "$file"
done
